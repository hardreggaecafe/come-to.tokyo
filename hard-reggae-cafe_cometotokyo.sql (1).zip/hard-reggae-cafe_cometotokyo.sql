-- phpMyAdmin SQL Dump
-- version 3.3.10.5
-- http://www.phpmyadmin.net
--
-- ホスト: mysql302.db.sakura.ne.jp
-- 生成時間: 2015 年 5 月 05 日 11:56
-- サーバのバージョン: 5.5.38
-- PHP のバージョン: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `hard-reggae-cafe_cometotokyo`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `accommodation`
--

CREATE TABLE IF NOT EXISTS `accommodation` (
  `accommodation_id` varchar(32) NOT NULL,
  `accommodation_name` varchar(128) NOT NULL,
  `tagline` varchar(64) NOT NULL,
  `headline` varchar(512) NOT NULL,
  `description` varchar(10240) NOT NULL,
  `charge` int(16) NOT NULL,
  `address` varchar(128) NOT NULL,
  `access` varchar(128) NOT NULL,
  `thumnail_url` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`accommodation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `accommodation`
--


-- --------------------------------------------------------

--
-- テーブルの構造 `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `article_id` varchar(32) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` varchar(512) NOT NULL,
  `keyword` varchar(512) NOT NULL,
  `body1` text NOT NULL,
  `body2` text NOT NULL,
  `body3` text NOT NULL,
  `body4` text NOT NULL,
  `body5` text NOT NULL,
  `language` varchar(16) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`article_id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `articles`
--

INSERT INTO `articles` (`article_id`, `title`, `description`, `keyword`, `body1`, `body2`, `body3`, `body4`, `body5`, `language`, `updatetime`) VALUES
('1', 'Guide your first travel in Tokyo', 'Come-to.tokyo supports your travel in Tokyo. We introduce nice places in Tokyo that maybe the places you dreamt to go. We also would like to help you solving problems about the travel. Well, just tell us what kind of travels do you want? ', 'Tokyo, Sightseeing, Travel, Recommendation,  Japan', '<div class="tagline"><h1>Come-to.tokyo supports your travel in Tokyo</h1><h2>We introduce nice places in Tokyo that maybe the places you dreamt to go. We also would like to help you solving problems about the travel. Well, just tell us what kind of travels do you want? </h2></div>', '', '', '', '', 'en', '2015-03-22 16:12:43'),
('1', 'はじめての東京観光旅行を満喫するガイド', '東京を観光するならCome-to.tokyo。行ってみたくなる場所を紹介したり、ちょっとした疑問を解決したりします。あなたはどんな旅がしたいですか？', '東京,観光,旅行,おすすめ,日本', '<div class="tagline">\r\n<h1>東京を観光するならCome-to.tokyo</h1><h2>行ってみたくなる場所を紹介したり、ちょっとした疑問を解決したりします。あなたはどんな旅がしたいですか？</h2>\r\n</div>', '', '', '', '', 'ja', '2015-03-21 13:26:59'),
('1', 'Hướng dẫn du lịch khi đến Tokyo', 'Nếu bạn muốn du lịch Tokyo, hãy tham khảo Come-to.tokyo. Chúng tôi sẽ giới thiệu những điểm các bạn nên đến  thăm quan, giải đáp những lo lắng nhỏ nhất của các bạn. Hãy cho chúng tôi biết các bạn muốn thăm quan như thế nào?', 'Tokyo, Điểm thăm quan, Du lịch, Lời khuyên, Nhật Bản', '<div class="tagline"><h1>Nếu bạn muốn du lịch Tokyo, hãy tham khảo Come-to.tokyo</h1><h2>Chúng tôi sẽ giới thiệu những điểm các bạn nên đến  thăm quan, giải đáp những lo lắng nhỏ nhất của các bạn. Hãy cho chúng tôi biết các bạn muốn thăm quan như thế nào?</h2></div>', '', '', '', '', 'vi', '2015-03-22 16:17:38'),
('1', '首次畅游东京的观光旅游指南', '畅游东京，找旅行攻略请看Come-to.tokyo。我们将为您介绍好看好玩好吃的东京景点，还愿意帮助您解决旅途中的疑惑。好啦，那么请告诉我们你想来一次怎样的东京之旅呢？', '东京, 观光, 旅游, 推荐, 日本', '<div class="tagline"><h1>畅游东京，找旅行攻略请看Come-to.tokyo</h1><h2>我们将为您介绍好看好玩好吃的东京景点，还愿意帮助您解决旅途中的疑惑。好啦，那么请告诉我们你想来一次怎样的东京之旅呢？</h2></div>', '', '', '', '', 'zh', '2015-03-22 16:12:43');

-- --------------------------------------------------------

--
-- テーブルの構造 `attraction`
--

CREATE TABLE IF NOT EXISTS `attraction` (
  `attraction_id` varchar(32) NOT NULL,
  `attraction_name` varchar(128) NOT NULL,
  `area` varchar(32) NOT NULL,
  `thumbnail` varchar(128) NOT NULL,
  `tagline` varchar(512) NOT NULL,
  `headline` text NOT NULL,
  `description` text NOT NULL,
  `tel_header` varchar(16) NOT NULL,
  `tel` varchar(128) NOT NULL,
  `address_header` varchar(16) NOT NULL,
  `address` varchar(128) NOT NULL,
  `access_header` varchar(16) NOT NULL,
  `access` varchar(1024) NOT NULL,
  `tradinghours_header` varchar(16) NOT NULL,
  `tradinghours_from` varchar(64) NOT NULL,
  `tradinghours_to` varchar(64) NOT NULL,
  `holidays_header` varchar(16) NOT NULL,
  `holidays` varchar(64) NOT NULL,
  `budget_header` varchar(32) NOT NULL,
  `budget_from` int(16) NOT NULL,
  `budget_to` int(16) NOT NULL,
  `creditcard_header` varchar(16) NOT NULL,
  `creditcard` varchar(64) NOT NULL,
  `seat_header` varchar(16) NOT NULL,
  `seat` varchar(128) NOT NULL,
  `chartered_room_header` varchar(16) NOT NULL,
  `chartered_room` varchar(64) NOT NULL,
  `chartered_header` varchar(16) NOT NULL,
  `charter` varchar(64) NOT NULL,
  `smoking_header` varchar(16) NOT NULL,
  `smoking` varchar(64) NOT NULL,
  `parking_header` varchar(16) NOT NULL,
  `parking` varchar(64) NOT NULL,
  `url` varchar(256) NOT NULL,
  `language` varchar(16) NOT NULL,
  `author_id` varchar(32) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attraction_id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `attraction`
--

INSERT INTO `attraction` (`attraction_id`, `attraction_name`, `area`, `thumbnail`, `tagline`, `headline`, `description`, `tel_header`, `tel`, `address_header`, `address`, `access_header`, `access`, `tradinghours_header`, `tradinghours_from`, `tradinghours_to`, `holidays_header`, `holidays`, `budget_header`, `budget_from`, `budget_to`, `creditcard_header`, `creditcard`, `seat_header`, `seat`, `chartered_room_header`, `chartered_room`, `chartered_header`, `charter`, `smoking_header`, `smoking`, `parking_header`, `parking`, `url`, `language`, `author_id`, `updatetime`) VALUES
('5531fe819a06d', 'Akihabara Radio Kaikan', 'Akihabara', '/images/5531fe819a06d/image09.jpg', 'Akihabara Radio Kaikan is located at Akihabara area which is famous for electrical equipment and “Cool Japan” Culture such as Anime, manga, game, and idols.', '<img alt="" src="/images/5531fe819a06d/image09.jpg"  class="article-image-large" >\r\n<p>\r\n Akihabara Radio Kaikan is popular between anime and manga fans from all over the world. You can find almost everything about anime, manga, cosplay, game in this building, even just going on escalators to see scenery out of  the window would be a good idea.\r\n</p>', '<img alt="" src="/images/5531fe819a06d/image10.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image11.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image12.jpg"  class="article-image-small" >\r\n<p>\r\n        Dolls, animated heroes , manga ... these are encountered in Akihabara Radio Kaikan.   \r\n           Exquisite doll will make both adults and children do hardly put it down.\r\n</p>\r\n<p>\r\n        Excellent animation are impressive on its original story, while everyone''s impression after  \r\n           reading are different, and therefore add to the fun of watching anime. These “differences”  \r\n           gradually developed into a kind of "re-creation” between fan of anime, known as   \r\n           "doujinshi”.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image13.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n The "doujinshi" in a thriving formed between fans are called "comike (comic market)". K-\r\n           BOOKS which is on the 3rd floor of the Akihabara Radio Kaikan, you can buy some \r\n           popular works there.\r\n</p>\r\n<p>\r\n There are many types of game from video games to table games, and of course the \r\n           classic " Magic: The Gatherings” is sold. Fans can go to the 7th floor TRECA PARK  \r\n           AKIBA 7  to find treasures.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image01.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image00.jpg"  class="article-image-small" >\r\n<p>\r\n "Trading Card" is a recreation to collect sports, anime, idols and other types of cards. The \r\n          "Magic: The Gatherings" upgrade collecting cards to card battle as a landmark initiative. \r\n           Here ''s a Card Battle indoor park, on weekend there will be a lot of fans gathered to play.\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image03.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image02.jpg"  class="article-image-small" >\r\n\r\n<p>\r\nNext comes the girls ( there are boys ) will see the heart of dolls. Azone Labelshop  \r\n           AKIHABARA on 7 floor descending on display a variety of dolls will definitely make you \r\n          feast for the eyes. For example, the following cute doll with national characteristics of \r\n          Japanese-style dress.\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image04.jpg"  class="article-image-small" >\r\n\r\n<p>\r\nReplacing parts of dolls’ bodies and dress is so called "custom doll". Fans can be \r\n           purchased at the 5th floor of the "Spacecraft" and "Aix" (names of shops ) to get the \r\n           exquisite doll parts and apparel and accessories.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image05.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image06.jpg" class="article-image-small" >\r\n\r\n<p>\r\n"Custom Doll" can be assembled in accordance with the preferences of their bodies. You can   \r\n     choose hair like the photographs showed above, and even draw  sophisticated makeup on   \r\n     their faces. Events fans show their custom dolls would let you feast for the eyes.\r\n</p>\r\n\r\n<p>\r\nWe are amazed at fine workmanship of Japanese dolls. “Kaiyodo” on the 5th floor and \r\n          “Utyusen” ( names of the shops) are placed a variety of dolls, including anime movie  \r\n          super heroes. Just looking at them will make you feel they are breathing!\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image07.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image08.jpg" class="article-image-small" >\r\n\r\n<p>\r\n While it’s a little luxury as a souvenir , but buying yourself a doll as a reward that can    \r\n         accompany you for a long long time is very reasonable. Timeless classic "Robocop" and  \r\nplayed by Angelina Jolie "black witch" should be familiar to foreign tourists.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image14.jpg" class="article-image-large" >\r\n\r\n<p>\r\nAlso at here you could meet cosplay enthusiasts . Saying hi to them and maybe you can \r\n           get a photo with them, isn’t it an interesting experience?\r\n</p>\r\n<p>\r\nAkihabara is a place so distinctive, and also is an important microcosm of Japanese \r\n         subculture. Here will make you experience an unusual feeling , be sure to come and see.\r\n</p>', 'TEL', '', 'address', '1-15-16 Soto-kanda Chiyoda-ku, Tokyo', 'Access', 'JR Akihabara Station  Denkigai-kuchi<br />10 minutes walk  from Tokyo Metro  Ginza Line Suehiro -cho Station No.1-3<br />5 minutes walk  from Tokyo Metro  Hibiya Line Akihabara Station No.2-3<br />3 minute walk  from TSUKUBA EXPRESS Akihabara Station A1', 'Open Time', '10:00', '20:00', '', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', 'Parking', 'Avaliable', 'http://www.akihabara-radiokaikan.co.jp/', 'en', '2', '2015-04-18 21:06:23'),
('5531fe819a06d', '秋葉原ラジオ会館', '秋葉原', '/images/5531fe819a06d/image09.jpg', '電気製品だけでなくアニメ、マンガ、ゲーム、アイドルといったクールジャパンコンテンツの発信地東京・秋葉原のおすすめ観光スポットから秋葉原ラジオ会館をご紹介。', '<img alt="" src="/images/5531fe819a06d/image09.jpg"  class="article-image-large" >\r\n<p>\r\n 秋葉原の駅前にあるラジオ会館には「世界の」との名前の通り、世界中から人が訪れている。建物の中にはアニメ、マンガ、コスプレ、ゲームなどあらゆるコンテンツが津凝縮されていて、エスカレーターで上ったり下りたりしながらいろんな店を眺めてくるのがオススメの楽しみ方だ。\r\n</p>', '<img alt="" src="/images/5531fe819a06d/image10.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image11.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image12.jpg"  class="article-image-small" >\r\n<p>\r\n        Wフィギュア、ヒーロー、マンガ、アニメ・・・これらすべてこのラジオ会館で出会えるものばかり。子どもから大人まで熱狂させる数々のアイテムはただのおもちゃとはいえない精密な質感が素晴らしい。\r\n</p>\r\n<p>\r\n        Wアニメやマンガはそれだけで素晴らしいコンテンツで見るものに感動を覚えさせるものであるが、同時に解釈も人それぞれ。だから無限に楽しめる。\r\nそういった楽しみを実際に「新しいストーリー」として作り直す作業がファンの間で行われている。それが「同人誌」というものである。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image13.jpg"  class="article-image-small" >\r\n<p>\r\n 同人誌もファンの間では新たなマーケットを作っていて「コミケ」と言われる大規模なコンベンションで取引されている。３FのK-BOOKSではその一部が入手できる。\r\n</p>\r\n<p>\r\n ゲームもビデオゲームからカードゲームまであらゆるジャンルが置いてあるが、古くからのファンにとって「マジック・ザ・ギャザリング」という名前は聞き覚えがあるだろう。そんな人には７FのTRECA PARK AKIBA 7がオススメだ。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image01.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image00.jpg"  class="article-image-small" >\r\n<p>\r\n トレーディングカード（いわゆるトレカ）とは収集目的のカードの総称だがスポーツ、アニメ、アイドルのカードを収集したことがある人もいるかもしれない。マジック・ザ・ギャザリングはこのトレカを対戦ゲームにしたという点で画期的かつ世界中でものすごい人気を誇る。ここトレカパークでは大戦スペースも設けられており、週末になると大勢のファンがバトルを繰り広げているのが見られる。\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image03.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image02.jpg"  class="article-image-small" >\r\n<p>\r\n次は女性（中には男性も？）も見て楽しめるドールである。７FのAzone Labelshop AKIHABARAでは沢山の着飾れたドールを見られるだろう。衣装だけでなくサイズも大きい物から小さいものまで様々。例えば日本文化を感じさせるこんなショーウィンドウもある。\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image04.jpg"  class="article-image-small" >\r\n<p>\r\nこういったドールを自作して楽しむ「カスタムドール」というジャンルも存在する。精密なフィギュアで有名な５Fの宇宙船、アキバのエックスあたりではこのようなパーツを入手可能である。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image05.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image06.jpg" class="article-image-small" >\r\n<p>\r\n「カスタムドール」はこれらのパーツを組み合わせて好みのフィギュアをつくるのだが、中には顔に丁寧に化粧を施して目玉やかつらを付けて冒頭にあるようなフランス人形のようなカワイイドールを作って楽しむコミュニティも存在する。ドールショー（略してドルショ）では多くのカスタムドールが見られるだろう。ファンはまるで自分の子どものようにドールに愛情を注いでいる。\r\n</p>\r\n\r\n<p>\r\nそして最後はなんといってもフィギュア。細部にまでこだわった造形美は日本ならでは。５Fの海洋堂と宇宙船では見ているだけでもため息が出そうなフィギュアがたくさんあり、見覚えのあるヒーローのフィギュアも置いている。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image07.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image08.jpg" class="article-image-small" >\r\n<p>\r\nおみやげで買うには少し高めだが自分へのご褒美に何か一つコレクターズアイテムとして買うのもいいだろう。ロボコップやマレフィセントは外国人にも馴染みがあるはず。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image14.jpg" class="article-image-large" >\r\n<p>\r\nまた多くのコスプレイヤーにも遭遇。声をかけて写真を撮らせてもらうのも秋葉原の楽しみの一つである。\r\n</p>\r\n<p>\r\n日本の中でも特に異文化を感じることができるエリアは、京都を除けばそんなにないが、ここ秋葉原には来る人を魅了する不思議な時間が流れているのは間違いない。\r\nぜひ体験して欲しい。\r\n</p>', 'TEL', 'ショップごと', '住所', '東京都千代田区外神田1-15-16 ', '交通手段', 'JR秋葉原駅　電気街口よりすぐ<br />東京メトロ日比谷線秋葉原駅 2-3番出口より徒歩5分<br />つくばエクスプレス秋葉原駅 A1出口より徒歩3分', '営業時間', '10:00', '20:00', '', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '駐車場', '有', 'http://www.akihabara-radiokaikan.co.jp/', 'ja', '1', '2015-04-18 15:51:56'),
('5531fe819a06d', 'Akihabara Radio Kaikan', 'Akihabara', '/images/5531fe819a06d/image09.jpg', 'Akihabara Radio Kaikan tọa lạc ở khu vực Akihabara, nơi nổi tiếng về các thiết bị điện và văn hóa “Cool Japan” như anime, manga, trò chơi và thần tượng.', '<img alt="" src="/images/5531fe819a06d/image09.jpg"  class="article-image-large" >\r\n<p>\r\n Akihabara Radio Kaikan rất nổi tiếng trên thế giới về anime và manga. Bạn có thể tìm được tất cả mọi thứ về anime, manga, cosplay, trò chơi ở đây, thậm chỉ chỉ là đi trên thang cuốn để ngắm nhìn phong cảnh cũng là một ý tưởng khá hay. \r\n</p>', '<img alt="" src="/images/5531fe819a06d/image10.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image11.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image12.jpg"  class="article-image-small" >\r\n<p>\r\n        Búp bê, mô hình nhân vật hoạt hình, manga ... đều có ở Akihabara Radio Kaikan. Những mô hình búp bê tinh xảo sẽ làm người lớn và trẻ em khó có thể bỏ qua\r\n</p>\r\n<p>\r\n        Những bộ phim hoạt hình tuyệt vời là những bộ phim ấn tượng từ cốt truyện, trong khi ấn tượng của mọi người sau khi đọc là khác nhau và vì thế đã thêm niềm vui vào việc xem anime. Những "điều khác nhau" này mặc nhiên đã phát triển thành một dạng "tái tạo" giữa các fan anime, được biết đến với tên "doujinshi”.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image13.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n"Doujinshi” là một hình thức đang được phát triển gữa các fan anime được gọi là "comike" (thị trường truyện tranh). K -BOOKS năm trên tầng 3 của khu Akihabara Radio Kaikan, tại đó bạn có thể mua những tác phẩm nổi tiếng.\r\n</p>\r\n<p>\r\nCó rất nhiều loại game từ video games đến game bàn và đương nhiên là game kinh điển "Magic: The Gatherings" đang được bán. Các fan thể lên tầng 7 TRECA PARK AKIBA để tìm các kho báo\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image01.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image00.jpg"  class="article-image-small" >\r\n<p>\r\n"Thẻ thương mại" là một sự sáng tạo nhằm thu thập các loại thẻ thể thao, hoạt hình, thần tương và các loại thẻ khác. "Sự kỳ diệu: Tu hội" nâng cấp những thẻ đã thu thập thành thẻ chiến đấu, nó giống như một bước ngoặt vậy. Đây là một thẻ chiến đấu của công viên trong nhà, vào dịp cuối tuần rất nhiều người thu thập chúng để chơi.\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image03.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image02.jpg"  class="article-image-small" >\r\n\r\n<p>\r\nTiếp đến những cô gái (thậm chí là chàng trai) sẽ nhìn thấy trái tim của búp bê. Tại Azono Labelshop AKIHABARA - tầng 7, hàng loạt búp bê được trưng bày sẽ làm bạn mãn nhãn ví dụ như những con búp bê đáng yêu trong trang phục truyền thống của Nhật Bản.\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image04.jpg"  class="article-image-small" >\r\n\r\n<p>\r\nThay thế một bộ phận trên cơ thể búp bê và thay quần áo còn được gọi là "Custom doll". Người hâm hộ có thể tới tầng 5, cửa hàng "Spacecraft" và "Aix""để mua những bộ phận búp bê tinh tế, váy áo và cả phụ kiện cho chúng.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image05.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image06.jpg" class="article-image-small" >\r\n\r\n<p>\r\n"Custom doll" được lắp ráp tùy thuộc vào sở thích của khách hàng. Bạn có thể chọn kiểu tóc trong những bức ảnh trên đây, và thậm chí vẽ những đường nét trang điểm phức tạp cho những con búp bê này. Những buổi họp fan sẽ làm bạn no mắt bởi cuộc triển lãm, trưng bày những con búp bê này.\r\n</p>\r\n\r\n<p>\r\nChúng tôi rất ngạc nhiên trước tài nghệ của những người làm búp bê Nhật Bản. "Kaiyodo" - tầng 5 và cửa hàng "Utyusen" là nơi rất nhiều búp bê được trưng bày, bao gồm cả những anh hùng trong phim hoạt hình Nhật Bản. Chỉ nhìn chúng tôi bạn cũng có thể thấy chúng đang sống.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image07.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image08.jpg" class="article-image-small" >\r\n\r\n<p>\r\nĐây có thể là một món quà lưu niệm đắt đỏ, tuy nhiên chẳng có gì là vô lý khi tự mua cho mình một con búp bê nhe một người bạn đồng hành cho quãng đường dài phía trước. "Robocop" cổ điển và phù thủy đen Angelina Jolie có thể là những cái tên quen thuộc với khách du lịch nước ngoài.\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image14.jpg" class="article-image-large" >\r\n\r\n<p>\r\nCũng ở đây, bạn có thể gặp những người đam mê cosplay. Chào hỏi họ và bạn có thể chụp ảnh với họ, một trải nghiệm tuyệt vời phải không?\r\n</p>\r\n<p>\r\nAkihabara là một nơi rất đặc biệt và cũng là một mô hình thu nhỏ của tiểu văn hóa Nhật Bản. Nơi đây sẽ khiến bạn có những trải nghiệm và cảm xúc mới lạ, hãy đến và trải nghiệm.\r\n</p>', 'Điện thoại', '', 'Địa chỉ', '1-15-16 Soto-kanda, phường Chiyoda, Tokyo', 'Lối vào', 'Trạm JR Akihabara, Denkigai-kuchi<br />10 phút đi bộ từ Tàu ngầm Tokyo, tuyến Ginza, số 1-3 Trạm Suehiro-cho <br />5 phút đi bộ từ Tàu ngầm Tokyo, tuyến Hibiya, số 2-3 Trạm Akihabara<br />3 phút đi bộ từ tàu cao tốc Tsukuba, số A1 trạm Akihabara', 'Giờ mở cửa', '10:00', '20:00', '', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', 'Parking', 'Có chỗ giữ xe', 'http://www.akihabara-radiokaikan.co.jp/', 'vi', '1', '2015-04-18 21:06:23'),
('5531fe819a06d', '秋叶原电台会馆', '秋叶原', '/images/5531fe819a06d/image09.jpg', '为您介绍位于不仅是电器制品，还是动漫电玩偶像团体等Cool Japan的潮流发祥地东京秋叶原的“秋叶原电台会馆”。', '<img alt="" src="/images/5531fe819a06d/image09.jpg"  class="article-image-large" >\r\n<p>\r\n 位于秋叶原车站前的电台会馆正如它招牌上的“世界”二字吸引了世界各地的动漫爱好者。这栋楼汇集着从经典到最具人气的动漫，cosplay，电玩和周边商品，乘坐扶梯上上下下眺望秋叶原街景也是其亮点之一。\r\n</p>', '<img alt="" src="/images/5531fe819a06d/image10.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image11.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image12.jpg"  class="article-image-small" >\r\n<p>\r\n        玩偶，动画英雄，动漫……这些都可以在秋叶原电台会馆里遇到。精致的玩偶会令不论小孩还是大人都爱不释手。\r\n</p>\r\n<p>\r\n        出色的动漫只看其原著就令人感动，而读后大家的理解与演绎各有不同，因此更增添了看动漫的乐趣。这种乐趣逐渐发展成为动漫粉丝之间的一种“再创作”，被称为“同人志”。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image13.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n 而“同人志”在粉丝间的兴盛形成了被称为“comike（comic market）”的交易市场。在秋叶原电台会馆的3楼的K-BOOKS上可以购买到一些人气作品。\r\n</p>\r\n<p>\r\n 游戏种类从电子游戏到桌牌游戏一应俱全，当然还有经典的“万智牌 (Magic: The Gatherings)”。粉丝可以到7楼的TRECA PARK AKIBA 7去一饱牌福。\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image01.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image00.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n “交换卡片(Trading Card)”是一种以收集体育运动，动漫，偶像等种类卡片为目的的娱乐活动。而“万智牌 (Magic: The Gatherings)”则是将收集卡片升级为对战卡片的一项划时代的创举。在这里的卡片对战室内公园一到周末就会有大量粉丝聚集玩耍。\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image03.jpg"  class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image02.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n接下来介绍女生（也有男生）一见就会心动的娃娃玩偶。7楼的Azone Labelshop AKIHABARA陈列的从大到小各式各样的娃娃绝对会让你大饱眼福。例如下图具有民族特色的日式风格着装的可爱娃娃。\r\n</p>\r\n<img alt="" src="/images/5531fe819a06d/image04.jpg"  class="article-image-small" >\r\n\r\n<p>\r\n还有一种为娃娃更换零部件，着装等叫做“定制娃娃”的玩法。喜欢的朋友可以在5楼的“宇宙船”和“艾克斯”（店名）购买到精美的娃娃零部件和服装及配饰。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image05.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image06.jpg" class="article-image-small" >\r\n<p>\r\n“定制娃娃”可以按照喜好来组装其身体，还可以像前面的照片里的娃娃那样为它们选择头发和画上精致的妆容。在这样像装扮自己的孩子一样来打扮娃娃的爱好者团体举办的娃娃秀活动里，一定会让你大饱眼福。\r\n</p>\r\n\r\n<p>\r\n最后不得不感叹的还是日本玩偶做工的精美。在5楼的海洋堂和宇宙船（店名）里摆放的包括电影动漫里的超级英雄们在内各种各样的玩偶，只是看看都会感觉到它们的呼吸！\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image07.jpg" class="article-image-small" >\r\n<img alt="" src="/images/5531fe819a06d/image08.jpg" class="article-image-small" >\r\n\r\n<p>\r\n虽然当作礼物有些奢侈，但是对于给自己犒赏买一个喜欢的玩偶它可以陪你很久很久呢。永恒经典的“机械战警”和由茱莉扮演的“黑魔女”应该会让外国游客产生共鸣。\r\n</p>\r\n\r\n<img alt="" src="/images/5531fe819a06d/image14.jpg" class="article-image-large" >\r\n\r\n<p>\r\n另外在这里你还可以遇到cosplay爱好者们。和他们友好的问声好也许可以换来一张合影也是个有趣的经历吧。\r\n</p>\r\n<p>\r\n秋叶原是如此个性鲜明的一个地方，是日本亚文化里的一个重要缩影，也是理解全面的现代日本的必经之处。来到这里会让你体验到不同寻常的感觉，请一定来看看吧。\r\n</p>', '电话', '', '地址', '东京都千代田区外神田1-15-16 ', '交通方式', 'JR秋叶原站    电器街口<br />东京地下铁银座线末广町站1-3号出口步行10分<br />东京地下铁日比谷线秋叶原站2-3号出口步行5分<br />TSUKUBA EXPRESS （筑波特快列车）秋叶原站A1出口步行3分', '营业时间', '10:00', '20:00', '', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '停车位', '有', 'http://www.akihabara-radiokaikan.co.jp/', 'zh', '2', '2015-04-18 20:54:41');

-- --------------------------------------------------------

--
-- テーブルの構造 `author`
--

CREATE TABLE IF NOT EXISTS `author` (
  `author_id` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `photo` varchar(256) NOT NULL,
  `email` varchar(128) NOT NULL,
  `facebook` varchar(64) NOT NULL,
  `twitter` varchar(64) NOT NULL,
  `weibo` varchar(64) NOT NULL,
  `introduction` varchar(512) NOT NULL,
  `nationality` varchar(64) NOT NULL,
  `language` varchar(16) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `author`
--

INSERT INTO `author` (`author_id`, `name`, `photo`, `email`, `facebook`, `twitter`, `weibo`, `introduction`, `nationality`, `language`, `updatetime`) VALUES
('1', 'Noriaki', '/images/author/1.png', 'takamizawa@come-to.tokyo', 'takamizawa', 'hardreggaecafe', '', 'Người sáng lập Come-to.tokyo, Kỹ sư IT và cũng có thể là người đại diện bán hàng cho Nhật Bản. Đừng ngần ngại liên hệ với tôi nhé', 'ja', 'vi', '2015-04-19 11:30:13'),
('1', 'Noriaki', '/images/author/1.png', 'takamizawa@come-to.tokyo', 'takamizawa', 'hardreggaecafe', '', '渋谷でエンジニアをやっています。いろんな国の人に日本の良さを知ってもらうのをミッションにしています。気軽に声をかけてください。', 'ja', 'ja', '2015-04-19 11:30:13'),
('1', 'Noriaki', '/images/author/1.png', 'takamizawa@come-to.tokyo', 'takamizawa', 'hardreggaecafe', '', 'Work for some IT company as engineer. My goal is to spread good point of Japan to the World. Please contact me any time.', 'ja', 'zh', '2015-04-19 11:30:13'),
('1', 'Noriaki', '/images/author/1.png', 'takamizawa@come-to.tokyo', 'takamizawa', 'hardreggaecafe', '', 'Work for some IT company as engineer. My goal is to spread good point of Japan to the World. Please contact me any time.', 'ja', 'en', '2015-04-19 11:30:13'),
('2', 'Zhang Yawei', '/images/author/2.png', 'bibiszhang@gmail.com', 'yawei.zhang.125', '', '', 'A Chinese graduate school student living in Tokyo.', 'zh', 'vi', '2015-04-19 19:04:38'),
('2', '張雅薇', '/images/author/2.png', 'bibiszhang@gmail.com', 'yawei.zhang.125', '', '', '大家好，我是来自中国的在东京生活的留学生。用中文传达日本的魅力。请华语圈的朋友们多多支持。', 'zh', 'zh', '2015-04-19 19:04:38'),
('2', '張雅薇(ちょう がび)', '/images/author/2.png', 'bibiszhang@gmail.com', 'yawei.zhang.125', '', '', '東京に在住している中国出身の留学生。日本の魅力を中国語で発信したい。中国語圏の皆さん、ぜひ応援してください〜', 'zh', 'ja', '2015-04-19 19:04:38'),
('2', 'Zhang Yawei', '/images/author/2.png', 'bibiszhang@gmail.com', 'yawei.zhang.125', '', '', 'A Chinese graduate school student living in Tokyo.', 'zh', 'en', '2015-04-19 19:04:38');

-- --------------------------------------------------------

--
-- テーブルの構造 `expedition`
--

CREATE TABLE IF NOT EXISTS `expedition` (
  `expedition_id` varchar(32) NOT NULL,
  `article` varchar(10240) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`expedition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `expedition`
--


-- --------------------------------------------------------

--
-- テーブルの構造 `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `image_id` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `path` varchar(256) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `images`
--


-- --------------------------------------------------------

--
-- テーブルの構造 `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `restaurant_id` varchar(32) NOT NULL,
  `restaurant_name` varchar(128) NOT NULL,
  `area` varchar(32) NOT NULL,
  `thumbnail` varchar(128) NOT NULL,
  `tagline` varchar(512) NOT NULL,
  `headline` text NOT NULL,
  `description` text NOT NULL,
  `tel_header` varchar(16) NOT NULL,
  `tel` varchar(128) NOT NULL,
  `address_header` varchar(16) NOT NULL,
  `address` varchar(128) NOT NULL,
  `access_header` varchar(16) NOT NULL,
  `access` varchar(128) NOT NULL,
  `tradinghours_header` varchar(16) NOT NULL,
  `tradinghours_from` varchar(64) NOT NULL,
  `tradinghours_to` varchar(64) NOT NULL,
  `holidays_header` varchar(16) NOT NULL,
  `holidays` varchar(64) NOT NULL,
  `budget_header` varchar(32) NOT NULL,
  `budget_from` int(16) NOT NULL,
  `budget_to` int(16) NOT NULL,
  `creditcard_header` varchar(16) NOT NULL,
  `creditcard` varchar(64) NOT NULL,
  `seat_header` varchar(16) NOT NULL,
  `seat` varchar(128) NOT NULL,
  `chartered_room_header` varchar(16) NOT NULL,
  `chartered_room` varchar(64) NOT NULL,
  `chartered_header` varchar(16) NOT NULL,
  `charter` varchar(64) NOT NULL,
  `smoking_header` varchar(16) NOT NULL,
  `smoking` varchar(64) NOT NULL,
  `parking_header` varchar(16) NOT NULL,
  `parking` varchar(64) NOT NULL,
  `url` varchar(256) NOT NULL,
  `language` varchar(16) NOT NULL,
  `author_id` varchar(32) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`restaurant_id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `restaurant`
--

INSERT INTO `restaurant` (`restaurant_id`, `restaurant_name`, `area`, `thumbnail`, `tagline`, `headline`, `description`, `tel_header`, `tel`, `address_header`, `address`, `access_header`, `access`, `tradinghours_header`, `tradinghours_from`, `tradinghours_to`, `holidays_header`, `holidays`, `budget_header`, `budget_from`, `budget_to`, `creditcard_header`, `creditcard`, `seat_header`, `seat`, `chartered_room_header`, `chartered_room`, `chartered_header`, `charter`, `smoking_header`, `smoking`, `parking_header`, `parking`, `url`, `language`, `author_id`, `updatetime`) VALUES
('550ec9627a494', 'bills Tokyu Plaza Omotesando Harajuku', 'Harajuku', '/images/550ec9627a494/image00.jpg', 'Introduce the popular restaurant named bills at Harajuku where you can find most fashionable people and things in Tokyo.', '<img alt="" src="/images/550ec9627a494/image00.jpg" class="article-image-large" >\r\n<p>\r\n “Bills” is from Austria and opened in several cities of other countries such as Tokyo and London. It was called “the best breakfast in the world” by the New York Times, even made effect on breakfast culture of Austria. If you want to have a taste of delicious hotcakes and egg dishes there, you had better make a reservation or make sure you have sufficient time, because its popularity always makes a long line of customers.\r\n</p>', '<img alt="" src="/images/550ec9627a494/image01.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image04.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image02.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image03.jpg" class="article-image-small" >\r\n\r\n<p>\r\n        “Bills” is at Tokyu Plaza 7F which is located on the Harajuku crossroad. It has an open and bright interior design looks like a cafe shop. Book and wine shelves, flowers make a literature and art atmosphere. However you have to finish your dinner in 2hours because of its popularity.\r\n\r\n</p>\r\n<img alt="" src="/images/550ec9627a494/image06.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image05.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image08.jpg" class="article-image-small" title="">\r\n<p>\r\n        We recommend Ricotta hotcake and scrambled egg.\r\n\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image07.jpg" class="article-image-large" title="">\r\n\r\n<p>\r\n        The menu is written in Japanese and English.\r\n\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image09.jpg" class="article-image-small" title="">\r\n\r\n<p>\r\n         We also recommend a pot of chamomile tea to have a relax time during your trip.\r\n\r\n</p>\r\n<p>\r\n        You had better go there before 10 a.m. or book a dinner to avoid rush time. \r\n\r\n</p>', 'TEL', '03-5772-1133  Reservations are accepted up to one month ahead, and for dinner only.', 'Address', 'Tokyu Plaza Omotesando Harajuku 7F 4-30-3 Jingu-mae, Shibuya-ku, Tokyo', 'Access', '192m from Tokyo Metro “Meiji-jinggumae” station', 'Trading hours', '8:30', '23:00', 'Holidays', 'We are usually open every day', 'Consumption per person', 2000, 2999, 'Credit Cards', 'Available Credit（VISA、MASTER、JCB、AMEX）', 'Seating', 'Main floor 108 seats, Terrace 14 seats', 'Chartered room', 'No chartered room', 'Charter service', 'No charter service', 'Smoking', 'All of our restaurants are non smoking', 'Parking', 'Available (42 car spaces)', 'https://bills-jp.net', 'en', '2', '2015-03-23 00:00:00'),
('550ec9627a494', 'bills 東急プラザ表参道原宿', '原宿', '/images/550ec9627a494/image00.jpg', 'ファッショントレンドの発信地、東京・原宿のおすすめ観光スポットからBills原宿をご紹介。', '<img alt="" src="/images/550ec9627a494/image00.jpg" class="article-image-large" >\r\n<p>\r\n        bills（ビルズ）は、オーストラリアに3店舗を展開するカジュアルダイニングレストラン。オーストラリアの朝食文化を変えたと言われる店でニューヨークタイムズで“世界一の朝食”と認定されたセレブも通うと言われている。パンケーキと卵料理は絶品で是非抑えておきたいが、行列が出来る店なので余裕を持って行くようにしたい。\r\n</p>', '<img alt="" src="/images/550ec9627a494/image01.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image04.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image02.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image03.jpg" class="article-image-small" >\r\n\r\n<p>\r\n        原宿交差点にある東急プラザの７FにあるBillsは常に行列ができる人気店。店内は見晴らしの良いオープンスタイルのカフェで回りは視界を遮るものがないからとても気持ち良い。奥にある本棚のインテリアやワインセラーも魅力的。天井の高さや空間の雰囲気だけでも居心地はいいのだが、並ぶ人気店らしく2時間位しかいられないらしいのは残念。\r\n</p>\r\n\r\n\r\n\r\n<img alt="" src="/images/550ec9627a494/image06.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image05.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image08.jpg" class="article-image-small" title="">\r\n<p>\r\n        オススメはリコッタパンケーキとオーガニックスクランブルエッグ。\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image07.jpg" class="article-image-large" title="">\r\n<p>\r\n        メニューは日本語と英語の両方があって外国人にもわかりやすい。\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image09.jpg" class="article-image-small" title="">\r\n<p>\r\n        リラックス効果があるカモミールティーも一緒に。\r\n</p>\r\n<p>\r\n        10:00より前にすればそれほど並ばずに入ることができるので朝食で行くか、夜は予約もできるのでディナーにBillsに行くのもいいかもしれない。\r\n</p>', 'TEL', '03-5772-1133　予約可', '住所', '東京都渋谷区神宮前4-30-3 東急プラザ 表参道原宿 　7F', '交通手段', '東京メトロ明治神宮前駅から192m', '営業時間', '8:30', '23:00', '定休日', '不定休', '予算', 2000, 2999, 'カード', '可 （VISA、MASTER、JCB、AMEX）', '席数', '122席 （メインフロア108席　/ テラス席14席）', '個室', '無', '貸切', '不可', '禁煙・喫煙', '完全禁煙', '駐車場', '有', 'https://bills-jp.net', 'ja', '1', '2015-04-19 00:00:00'),
('550ec9627a494', 'bills Tokyu Plaza Omotesando Harajuku', 'Harajuku', '/images/550ec9627a494/image00.jpg', 'IGiới thiệu về nhà hàng "Bills" tại Harajuku, nơi bạn có thể tìm thấy những con người và mọi điều thời trang nhất ở Tokyo.', '<img alt="" src="/images/550ec9627a494/image00.jpg" class="article-image-large" >\r\n<p>\r\n"Bills" đến từ nước Úc và có mặt ở 1 thành phố ở các quốc gia khác nhau như Tokyo và London. Nhà hàng được tờ báo New York Times đánh giá là "bữa sáng ngon nhất thế giới", mặc đù có ảnh hưởng của văn hóa Úc. Nếu bạn muốn nếm thử món bánh tươi và các món về trứng, bạn nên đặt bàn trước và chắc chắn bạn phải có đủ thời gian, bởi vì sự nổi tiếng của nhà hàng luôn tạo nên một hàng dài thực khách chờ đợi.\r\n</p>', '<img alt="" src="/images/550ec9627a494/image01.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image04.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image02.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image03.jpg" class="article-image-small" >\r\n\r\n<p>\r\n“Bills” nằm trên tầng 7F của trung tâm thương mại Tokyu Plaza, tọa lạc ở ngã tư Harajuku. Nhà hàng có thiết kế nội thất mở và tươi sáng, trông giống một quán cà phê. Những giá sách và tủ rượu, những bông hoa tạo nên một bầu không khí đậm chất văn học và nghệ thuật. Tuy nhiên để hoàn thành xong bữa tối của bạn lại cần đến 2 giờ vì nhà hàng khá đông khách.\r\n\r\n</p>\r\n<img alt="" src="/images/550ec9627a494/image06.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image05.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image08.jpg" class="article-image-small" title="">\r\n<p>\r\nChúng tôi đề cử món bánh Ricotta và món Scrambled egg.\r\n\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image07.jpg" class="article-image-large" title="">\r\n\r\n<p>\r\nThực đơn được viết bằng tiếng Anh và tiếng Nhật.\r\n\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image09.jpg" class="article-image-small" title="">\r\n\r\n<p>\r\nChúng tôi cũng đề cử một ấm trà hoa cúc để có khoảng thời gian thư giãn trong suốt bữa ăn của bạn.\r\n\r\n</p>\r\n<p>\r\nBạn nên đến trước 10 giờ sáng hoặc đặt bàn cho bữa tối để tránh tình trạng hết bàn.\r\n\r\n</p>', 'Điện thoại', '03-5772-1133 Thời gian đặt bàn tối đa là 1 tháng, và chỉ cho bữa tối.', 'Địa chỉ', 'Tokyu Plaza Omotesando Harajuku 7F 4-30-3 Jingu-mae, Shibuya-ku, Tokyo', 'Cách ga', '192m from Tokyo Metro “Meiji-jinggumae” station', 'Thời gian mở cửa', '8:30', '23:00', 'Nghỉ lễ', 'Chúng tôi mở cửa hàng ngày', 'Giá trung bình cho một người', 2000, 2999, 'Credit Cards', 'Chấp nhận thẻ Credit (VISA, MASTER, JCB, AMEX)', 'Phòng chính', '108 chỗ, ngoài trời: 14 chỗ', 'Phòng riêng', 'Không có', 'Dịch vụ trọn gói', 'Không có', 'Hút thuốc', 'Chuỗi nhà hàng của chúng tôi cấm hút thuốc', 'Parking', 'Có chỗ đỗ xe (42 xe)', 'https://bills-jp.net', 'vi', '1', '2015-04-12 00:00:00'),
('550ec9627a494', 'bills 东急plaza表参道原宿', '原宿', '/images/550ec9627a494/image00.jpg', '为您介绍位于东京流行时尚发源地的原宿的名店之一，餐饮店bills。', '<img alt="" src="/images/550ec9627a494/image00.jpg" class="article-image-large" >\r\n<p>\r\n        bills是起源于澳大利亚，并成功打入东京、伦敦等地的休闲餐饮店。据说bills的兴起甚至改变了澳大利亚的早餐文化，并被纽约时报誉为“世界第一的早餐”。如果您也想光临bills品尝那里美味的热香饼和蛋料理，请一定提早或者预约，因为好口碑常常让客人排起长龙。\r\n</p>', '<img alt="" src="/images/550ec9627a494/image01.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image04.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image02.jpg" class="article-image-small" >\r\n<img alt="" src="/images/550ec9627a494/image03.jpg" class="article-image-small" >\r\n\r\n<p>\r\n       bills位于原宿十字路口的东急plaza7楼，店内采用明快色调及开放式咖啡厅设计风格，另人心旷神怡。里面的书架和红酒架，鲜花又为餐厅增添了文艺气息。高高的天棚和宽阔的空间让用餐体验变得舒适，但因为人气过高，繁忙时限时2小时是bills原宿店的无奈之举。\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image06.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image05.jpg" class="article-image-small" title="">\r\n<img alt="" src="/images/550ec9627a494/image08.jpg" class="article-image-small" title="">\r\n<p>\r\n        小编推荐里考塔（一种起源于意大利的奶制品）热香饼和有机炒蛋。\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image07.jpg" class="article-image-large" title="">\r\n\r\n<p>\r\n        菜单为日英双语。\r\n</p>\r\n\r\n<img alt="" src="/images/550ec9627a494/image09.jpg" class="article-image-small" title="">\r\n\r\n<p>\r\n        还推荐您来一壶赏心悦目的洋甘菊茶，来放松旅途疲劳。\r\n</p>\r\n<p>\r\n        建议您为避开高峰选择上午10点前去吃早餐，或者预约晚餐。\r\n</p>', 'TEL ', '03-5772-1133　可提前', '地址', '东京都涩谷区神宫前4-30-3 东急plaza 表参道原宿      7楼', '交通', '东京地铁“明治神宫前”车站下车192米', '营业时间', '8:30', '23:00', '休息', '不定期休息', '人均消费', 2000, 2999, '可刷卡', '可刷卡（VISA、MASTER、', '座位数', '122座 （一般座108座／天台座14座）', '包间', '无包间', '包场', '不可包场', '禁烟', '全餐厅禁烟', '停车场', '无专用停车场', 'https://bills-jp.net', 'zh', '2', '2015-03-23 00:00:00');

-- --------------------------------------------------------

--
-- テーブルの構造 `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `shop_id` varchar(32) NOT NULL,
  `shop_name` varchar(128) NOT NULL,
  `area` varchar(32) NOT NULL,
  `thumbnail` varchar(128) NOT NULL,
  `tagline` varchar(512) NOT NULL,
  `headline` text NOT NULL,
  `description` text NOT NULL,
  `tel_header` varchar(16) NOT NULL,
  `tel` varchar(128) NOT NULL,
  `address_header` varchar(16) NOT NULL,
  `address` varchar(128) NOT NULL,
  `access_header` varchar(16) NOT NULL,
  `access` varchar(128) NOT NULL,
  `tradinghours_header` varchar(16) NOT NULL,
  `tradinghours_from` varchar(64) NOT NULL,
  `tradinghours_to` varchar(64) NOT NULL,
  `holidays_header` varchar(16) NOT NULL,
  `holidays` varchar(64) NOT NULL,
  `budget_header` varchar(32) NOT NULL,
  `budget_from` int(16) NOT NULL,
  `budget_to` int(16) NOT NULL,
  `creditcard_header` varchar(16) NOT NULL,
  `creditcard` varchar(64) NOT NULL,
  `seat_header` varchar(16) NOT NULL,
  `seat` varchar(128) NOT NULL,
  `chartered_room_header` varchar(16) NOT NULL,
  `chartered_room` varchar(64) NOT NULL,
  `chartered_header` varchar(16) NOT NULL,
  `charter` varchar(64) NOT NULL,
  `smoking_header` varchar(16) NOT NULL,
  `smoking` varchar(64) NOT NULL,
  `parking_header` varchar(16) NOT NULL,
  `parking` varchar(64) NOT NULL,
  `url` varchar(256) NOT NULL,
  `language` varchar(16) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`shop_id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `shop`
--


-- --------------------------------------------------------

--
-- テーブルの構造 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `facebook_id` varchar(16) NOT NULL,
  `weibo_id` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータをダンプしています `user`
--

